<%@page import="in.pentagon.studentApp.dto.Student"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
 pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<style>
.heading {
color: #000080;
}
.sub {
color: #1e90ff;
}
.success
{
color:green;
}
.failure
{
color:red;
}
</style>
<link rel="stylesheet"
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body bgcolor='#add8e6'>
<div align="center">
 <h1 class="heading">Pentagon Space</h1>
 <h3 class="sub">Update your account</h3>
<!-- Calling student object from session object -->
<%Student s=(Student)session.getAttribute("student"); %>