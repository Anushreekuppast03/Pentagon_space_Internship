import nltk

# ===============================
# DOWNLOAD REQUIRED RESOURCES
# (Run once – safe to keep here)
# ===============================
nltk.download('punkt')
nltk.download('punkt_tab')   # IMPORTANT for latest NLTK
nltk.download('stopwords')
nltk.download('averaged_perceptron_tagger_eng')
nltk.download('wordnet')

# ===============================
# IMPORT REQUIRED MODULES
# ===============================
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from nltk import pos_tag

# ===============================
# SAMPLE TEXT
# ===============================
text = """NLTK is a leading platform for building Python programs to work with human
language data. It provides easy-to-use interfaces to over 50 corpora and lexical resources such
as WordNet."""

# ===============================
# a. SENTENCE TOKENIZATION
# ===============================
sentences = sent_tokenize(text)
print("Sentence Tokenization:")
print(sentences)

# ===============================
# WORD TOKENIZATION
# ===============================
words = word_tokenize(text)
print("\nWord Tokenization:")
print(words)

# ===============================
# b. STOP WORD REMOVAL
# ===============================
stop_words = set(stopwords.words('english'))
filtered_words = [word for word in words if word.lower() not in stop_words]

print("\nFiltered Words (Stop Words Removed):")
print(filtered_words)

# ===============================
# c. STEMMING
# ===============================
stemmer = PorterStemmer()
stemmed_words = [stemmer.stem(word) for word in filtered_words]

print("\nStemmed Words:")
print(stemmed_words)

# ===============================
# d. POS TAGGING
# ===============================
pos_tags = pos_tag(words)
print("\nPart of Speech Tagging:")
print(pos_tags)