import numpy as np
import matplotlib.pyplot as plt

def locally_weighted_regression(x, y, tau, x_query):
    m = len(x)

    # Compute weights
    w = np.exp(-np.sum((x - x_query) ** 2, axis=1) / (2 * tau ** 2))
    w = np.diag(w)

    # Add bias term
    x_b = np.c_[np.ones((m, 1)), x]

    # Compute theta
    theta = np.linalg.pinv(x_b.T @ w @ x_b) @ x_b.T @ w @ y

    # Query point with bias
    x_query_b = np.array([1, x_query])

    return x_query_b @ theta


# Generate data
np.random.seed(0)
x = 2 * np.random.rand(100, 1)
y = (3 + 2 * x + np.random.randn(100, 1)).flatten()

# Sort data
x = x.flatten()
sort_idx = np.argsort(x)
x = x[sort_idx]
y = y[sort_idx]

# Bandwidth
tau = 0.1

# Test points
x_test = np.linspace(x.min(), x.max(), 100)

# Predictions
y_pred = [
    locally_weighted_regression(x[:, np.newaxis], y, tau, x_query)
    for x_query in x_test
]

# Visualization
plt.figure(figsize=(10, 6))
plt.scatter(x, y, color='blue', label='Data points')
plt.plot(x_test, y_pred, color='red', label='LWR fit')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.show()
